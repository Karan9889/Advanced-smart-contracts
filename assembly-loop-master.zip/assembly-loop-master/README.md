# assembly-loop

Following the steps to complete this exercise:
1. clone this project
1. install packages: npm install
1. run the test: npm test
1. the test should fail the gas test
1. fix the failed test case by updating the BitWise.sol contract
   - replace the logic in the countBitSetAsm() with inline assembly logic
1. add a test case to verify the result for countBitSetAsm(0)
1. commit your changes to github and submit your github url
