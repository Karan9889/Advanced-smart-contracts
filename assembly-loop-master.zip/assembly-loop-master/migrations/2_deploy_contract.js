const BitWise = artifacts.require('BitWise');

module.exports = function(deployer) {
    deployer.deploy(BitWise);
}